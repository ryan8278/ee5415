package com.example.fragmentactiontabs;

import android.app.Fragment;
import android.app.FragmentManager;
import android.support.v13.app.FragmentPagerAdapter;

import java.util.ArrayList;

/**
 * Created by Fanglin Chen on 12/18/14.
 */

public class ActionTabsViewPagerAdapter extends FragmentPagerAdapter {
    private ArrayList<Fragment> fragments;

    public static final int SHOP = 0;
    public static final int EMERGENCY = 1;
    public static final int POST = 2;
    public static final int FIND = 3;
    public static final int PROFILE = 4;
    public static final String UI_TAB_SHOP = "SHOP";
    public static final String UI_TAB_EMERGENCY = "EMERGENCY";
    public static final String UI_TAB_POST = "POST";
    public static final String UI_TAB_FIND = "FIND";
    public static final String UI_TAB_PROFILE = "PROFILE";


    public ActionTabsViewPagerAdapter(FragmentManager fm, ArrayList<Fragment> fragments){
        super(fm);
        this.fragments = fragments;
    }

    public Fragment getItem(int pos){
        return fragments.get(pos);
    }

    public int getCount(){
        return fragments.size();
    }

    public CharSequence getPageTitle(int position) {
        switch (position) {
            case SHOP:
                return UI_TAB_SHOP;
            case EMERGENCY:
                return UI_TAB_EMERGENCY;
            case POST:
                return UI_TAB_POST;
            case FIND:
                return UI_TAB_FIND;
            case PROFILE:
                return UI_TAB_PROFILE;
            default:
                break;
        }
        return null;
    }

}


