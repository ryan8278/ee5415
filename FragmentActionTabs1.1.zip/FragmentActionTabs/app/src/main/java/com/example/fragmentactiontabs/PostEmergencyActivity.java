package com.example.fragmentactiontabs;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;

/**
 * Created by heather on 2016/2/23.
 */
public class PostEmergencyActivity extends AppCompatActivity {
    EditText editTitle, editDescription, editRewards;
    Button locationButton, helpButton;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_emergency);
        editTitle = (EditText) findViewById(R.id.activity_post_emergency_edit_title);
        editDescription = (EditText) findViewById(R.id.activity_post_emergency_edit_description);
        editRewards = (EditText) findViewById(R.id.activity_post_emergency_edit_rewards);
        helpButton = (Button) findViewById(R.id.activity_post_emergency_button_help);
    }
}
