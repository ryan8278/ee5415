package com.example.fragmentactiontabs;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;

import com.example.fragmentactiontabs.view.SlidingTabLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private SlidingTabLayout slidingTabLayout;
    private ViewPager viewPager;
    private ArrayList<Fragment> fragments;
    private ActionTabsViewPagerAdapter myViewPageAdapter;

    private TextView user_evas;
    private ScrollView scrollview;

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //By yan yan
        slidingTabLayout = (SlidingTabLayout) findViewById(R.id.activity_main_tab);
        viewPager = (ViewPager) findViewById(R.id.activity_main_viewpager);
        // create a fragment list in order.
        fragments = new ArrayList<Fragment>();
        fragments.add(new ShopFragment());
        fragments.add(new EmergencyFragment());
        fragments.add(new PostFragment());
        fragments.add(new FindFragment());
        fragments.add(new ProfileFragment());
        // use FragmentPagerAdapter to bind the slidingTabLayout (tabs with different titles)
        // and ViewPager (different pages of fragment) together.
        myViewPageAdapter = new ActionTabsViewPagerAdapter(getFragmentManager(),
                fragments);
        viewPager.setAdapter(myViewPageAdapter);
        // make sure the tabs are equally spaced.
        slidingTabLayout.setDistributeEvenly(true);
        slidingTabLayout.setViewPager(viewPager);

        /***************By Yoyo**************/
        /*scrollview = (ScrollView)findViewById(R.id.profilefragment_scrollViewOther);
        user_evas=(TextView)findViewById(R.id.profilefragment_text_evaTxtOther);
        user_evas.setId(R.id.yoyo_user_evas);
        user_evas.setText(R.string.yoyo_userEvas);
        RelativeLayout.LayoutParams lp1 = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp1.topMargin = 10;
        scrollview.addView(user_evas, lp1);*/
    }

    public void postClick(View view) {
        Intent intent = null;
        switch (view.getId()) {
            case R.id.postfragment_imagebotton_sell:
                intent = new Intent(this, PostBuyActivity.class);
                startActivity(intent);
                break;
            case R.id.postfragment_imagebutton_buy:
                intent = new Intent(this, PostSellActivity.class);
                startActivity(intent);
                break;
            case R.id.postfragment_imagebutton_emergency:
                intent = new Intent(this, PostEmergencyActivity.class);
                startActivity(intent);
                break;
        }
    }
    public void goToSecondActivity(View v) {
        Intent intent = new Intent(this, ProfileSettingActivity.class);
        startActivity(intent);
    }
}