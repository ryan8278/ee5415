package com.example.fragmentactiontabs;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity {


    EditText edit_username;
    EditText edit_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        edit_username = (EditText) findViewById(R.id.joe_username);
        edit_password = (EditText) findViewById(R.id.joe_password);

    }

    public void sign_in(View view) {
        // sign in by sending the information to the Digger server
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void register_page(View view) {

        Intent intent = new Intent(this, RegisterActivity.class);
        Bundle bundle = new Bundle();
        bundle.putString("username", edit_username.getText().toString());
        bundle.putString("password", edit_password.getText().toString());
        intent.putExtras(bundle);
        startActivity(intent);
    }
}
