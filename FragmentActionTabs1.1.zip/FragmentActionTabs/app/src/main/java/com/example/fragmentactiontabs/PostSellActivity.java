package com.example.fragmentactiontabs;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

/**
 * Created by heather on 2016/2/23.
 */
public class PostSellActivity extends AppCompatActivity {

    private static final int TAKE_PHOTO_ID = 0;
    Bitmap bitmap;
    private ImageButton imageButton;
     EditText editTitle,editDescription,editPrice;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_sell);
        imageButton = (ImageButton) findViewById(R.id.activity_post_sell_imageview_sell2);
        editTitle = (EditText) findViewById(R.id.activity_post_sell_edit_title_sell);
        editDescription= (EditText) findViewById(R.id.activity_post_sell_edit_description_sell);
        editPrice= (EditText) findViewById(R.id.activity_post_sell_edit_price_sell);

        imageButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, TAKE_PHOTO_ID);
            }
        });
    }

    /* public void chooseProductPicture(View View) {

         Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);     startActivityForResult(intent, TAKE_PHOTO_ID);
     }*/
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == TAKE_PHOTO_ID) {
            if (data != null && data.hasExtra("data")) {
                bitmap = data.getParcelableExtra("data");
                imageButton.setImageBitmap(bitmap);
                //Toast.makeText(this, "A photo is taken.", Toast.LENGTH_LONG).show();


            }
        }
    }
    public void chooseCategory(View view){
        Intent intent = new Intent(this,CategoryListview.class);
        startActivity(intent);
        Log.i("success", "success");


    }
   // public void postSellProduct(View view){
        /*String title =editTitle.getText().toString();
        String description =editDescription.getText().toString();
        String price =editPrice.getText().toString();
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, os);
        ContentValues values = new  ContentValues();
        values.put("name",title);
        values.put("description",description);
        values.put("price",price);
        values.put("image", os.toByteArray());
        values.put("type","sell");
        values.put("state",0);
        values.put("userid",123);
        CategoryListview getItemName = new CategoryListview();
        String category =getItemName.returnString();
        values.put("category",category);
        DBHelper helper = new DBHelper(getApplicationContext());
        helper.insert(values);
        helper.close();*/


  //  }
}