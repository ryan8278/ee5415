package com.example.fragmentactiontabs;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

public class RegisterActivity extends AppCompatActivity {


    EditText edit_username;
    EditText edit_password;
    EditText edit_sid;
    EditText edit_email;
    EditText edit_phone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Bundle bundle = getIntent().getExtras();
        String username = bundle.getString("username");
        String password = bundle.getString("password");

        edit_username = (EditText) findViewById(R.id.joe_username);
        edit_password = (EditText) findViewById(R.id.joe_password);
        edit_sid = (EditText) findViewById(R.id.joe_sid);
        edit_email = (EditText) findViewById(R.id.joe_email);
        edit_phone = (EditText) findViewById(R.id.joe_phone);

        edit_username.setText(username);
        edit_password.setText(password);


    }

    public void register(View view) {
        // register by sending the information to the Digger server
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

    public void clear(View view) {

        AlertDialog.Builder builder = new AlertDialog.Builder(RegisterActivity.this);
        builder.setMessage(R.string.joe_msg_clear);
        builder.setPositiveButton(R.string.joe_yes, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                edit_username.setText("");
                edit_password.setText("");
                edit_sid.setText("");
                edit_email.setText("");
                edit_phone.setText("");
            }
        });
        builder.setNegativeButton(R.string.joe_no, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();

    }
}

