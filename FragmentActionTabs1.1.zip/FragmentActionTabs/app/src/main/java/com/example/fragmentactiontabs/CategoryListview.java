package com.example.fragmentactiontabs;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by heather on 2016/3/5.
 */
public class CategoryListview  extends ListActivity {
    String gettext;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String[] category = getResources().getStringArray(R.array.category);
        setListAdapter(new ArrayAdapter<String>(this, R.layout.list_item, category));
        ListView lv = getListView();
        lv.setTextFilterEnabled(true);
        lv.setOnItemClickListener(new ListView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
// When clicked, show a toast with the TextView text
                Intent intent = new Intent(CategoryListview.this,PostSellActivity.class);
                startActivity(intent);
                Toast.makeText(getApplicationContext(), ((TextView) view).getText(),
                        Toast.LENGTH_SHORT).show();
                gettext = ((TextView) view).getText().toString();
                Log.i("okok","okok");
            }
        });


    }
   // public  String returnString(){
      //  return gettext;
  //  }
}

