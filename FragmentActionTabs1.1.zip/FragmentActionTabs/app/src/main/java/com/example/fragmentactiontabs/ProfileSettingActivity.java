package com.example.fragmentactiontabs;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class ProfileSettingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_setting);
    }

    public void onClickBack(View v) {
        ProfileSettingActivity.this.finish();
    }
}
