package com.example.fragmentactiontabs;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by heather on 2016/2/23.
 */
public class postSell extends AppCompatActivity {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sell);
    }
}